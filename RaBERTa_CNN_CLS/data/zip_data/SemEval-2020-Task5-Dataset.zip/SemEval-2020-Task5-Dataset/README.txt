SemEval-2020 Task 5: Modelling Causal Reasoning in Language: Detecting Counterfactuals


- The directory consists of: 
./Subtask-1: data for subtask1
./Subtask-2: data for subtask2
./Baseline-Subtask1-SVM: SVM script for subtask1
./Baseline-Subtask2-SequenceLabeling: Sequence labeling model for subtask2


- Codalab Website: https://competitions.codalab.org/competitions/21691


- Our dataset is allowed to be used in any paper, only upon citation (BibTex as below):
(1) LaTex version:

@inproceedings{yang-2020-semeval-task5,

title = "{S}em{E}val-2020 Task 5: Counterfactual Recognition",

author = "Yang, Xiaoyu  and

  Obadinma, Stephen and

  Zhao, Huasha  and

  Zhang, Qiong  and

  Matwin, Stan  and

  Zhu, Xiaodan", 

booktitle = "Proceedings of the 14th International Workshop on Semantic Evaluation (SemEval-2020)",

year = "2020",

address = "Barcelona, Spain",

}

 

(2) MS Word:

Xiaoyu Yang, Stephen Obadinma, Huasha Zhao, Qiong Zhang, Stan Matwin, and Xiaodan Zhu.  2020. SemEval-2020 Task 5: Counterfactual Recognition. In Proceedings of the 14th International Workshop on Semantic Evaluation (SemEval-2020), Barcelona, Spain.


